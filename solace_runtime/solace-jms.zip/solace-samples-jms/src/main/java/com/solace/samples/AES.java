package com.solace.samples;

import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.Security;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;

import org.bouncycastle.jce.provider.BouncyCastleProvider;

public class AES {
  public static byte[] encrypt(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte[] paramArrayOfbyte3) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
    return transform(1, paramArrayOfbyte1, paramArrayOfbyte2, paramArrayOfbyte3);
  }
  
  public static byte[] decrypt(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte[] paramArrayOfbyte3) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
    return transform(2, paramArrayOfbyte1, paramArrayOfbyte2, paramArrayOfbyte3);
  }
  
  private static byte[] transform(int paramInt, byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte[] paramArrayOfbyte3) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException {
	Security.addProvider(new BouncyCastleProvider());
	SecretKeySpec secretKeySpec = new SecretKeySpec(paramArrayOfbyte1, "AES");
    IvParameterSpec ivParameterSpec = new IvParameterSpec(paramArrayOfbyte2);
    Cipher cipher = Cipher.getInstance("AES/CBC/PKCS7Padding");
    cipher.init(paramInt, secretKeySpec, ivParameterSpec);
    return cipher.doFinal(paramArrayOfbyte3);
  }
  
  public static String encryptBase64AES(String paramString1, String paramString2, String paramString3) {
    try {
      byte[] arrayOfByte1 = DatatypeConverter.parseBase64Binary(paramString1);
      byte[] arrayOfByte2 = DatatypeConverter.parseBase64Binary(paramString2);
      byte[] arrayOfByte3 = paramString3.getBytes();
      byte[] arrayOfByte4 = encrypt(arrayOfByte1, arrayOfByte2, arrayOfByte3);
      return DatatypeConverter.printBase64Binary(arrayOfByte4);
    } catch (Exception exception) {
      throw new RuntimeException(exception);
    } 
  }
  
  public static String decryptBase64AES(String paramString1, String paramString2, String paramString3) {
    try {
      byte[] arrayOfByte1 = DatatypeConverter.parseBase64Binary(paramString1);
      byte[] arrayOfByte2 = DatatypeConverter.parseBase64Binary(paramString2);
      byte[] arrayOfByte3 = DatatypeConverter.parseBase64Binary(paramString3);
      byte[] arrayOfByte4 = decrypt(arrayOfByte1, arrayOfByte2, arrayOfByte3);
      return DatatypeConverter.printBase64Binary(arrayOfByte4);
    } catch (Exception exception) {
      throw new RuntimeException(exception);
    } 
  }
  
  public static String encryptHexAES(String paramString1, String paramString2, String paramString3) {
    try {
      byte[] arrayOfByte1 = DatatypeConverter.parseHexBinary(paramString1);
      byte[] arrayOfByte2 = DatatypeConverter.parseHexBinary(paramString2);
      byte[] arrayOfByte3 = paramString3.getBytes();
      byte[] arrayOfByte4 = encrypt(arrayOfByte1, arrayOfByte2, arrayOfByte3);
      return DatatypeConverter.printHexBinary(arrayOfByte4);
    } catch (Exception exception) {
      throw new RuntimeException(exception);
    } 
  }
  
  public static String decryptHexAES(String paramString1, String paramString2, String paramString3) {
    try {
      byte[] arrayOfByte1 = DatatypeConverter.parseHexBinary(paramString1);
      byte[] arrayOfByte2 = DatatypeConverter.parseHexBinary(paramString2);
      byte[] arrayOfByte3 = DatatypeConverter.parseHexBinary(paramString3);
      byte[] arrayOfByte4 = decrypt(arrayOfByte1, arrayOfByte2, arrayOfByte3);
      return DatatypeConverter.printHexBinary(arrayOfByte4);
    } catch (Exception exception) {
      throw new RuntimeException(exception);
    } 
  }
  
  public static void main(String[] paramArrayOfString) throws Exception {
    String str1 = DatatypeConverter.printHexBinary(DatatypeConverter.parseBase64Binary("ABEiM0RVZneImaq7zN3u/w=="));
    String str2 = DatatypeConverter.printHexBinary(DatatypeConverter.parseBase64Binary("AAECAwQFBgcICQoLDA0ODw=="));
    String str3 = encryptBase64AES("ABEiM0RVZneImaq7zN3u/w==", "AAECAwQFBgcICQoLDA0ODw==", "Hello world!");
    String str4 = decryptBase64AES("ABEiM0RVZneImaq7zN3u/w==", "AAECAwQFBgcICQoLDA0ODw==", str3);
    String str5 = new String(DatatypeConverter.parseBase64Binary(str4), "UTF-8");
    System.out.println("Using Base64 encoding");
    System.out.println("Message  : Hello world!");
    System.out.println("Encrypted: " + str3);
    System.out.println("Decrypted (base64): " + str4);
    System.out.println("Decrypted: " + str5);
    String str6 = encryptHexAES(str1, str2, "Hello world!");
    String str7 = decryptHexAES(str1, str2, str6);
    String str8 = new String(DatatypeConverter.parseHexBinary(str7), "UTF-8");
    System.out.println("Using Hex encoding");
    System.out.println("Message  : Hello world!");
    System.out.println("Encrypted: " + str6);
    System.out.println("Decrypted (hex): " + str7);
    System.out.println("Decrypted: " + str8);
  }
  
  public static final String[][] HELP_STRINGS = new String[][] { { "decryptBase64AES", "Decrypts a base64-encoded byte array into base64-encoded plan bytes", "decryptBase64AES(key, iv, \"9Dl+bZUZ3/RT9mQNlKI14w==\") // this should return \"SGVsbG8gd29ybGQh\"", "The decrypted plain text." }, { "encryptBase64AES", "Encrypts base64-encoded plan bytes into base64-encoded bytes", "encryptBase64AES(key, iv, \"Hello world!\") // this should return \"9Dl+bZUZ3/RT9mQNlKI14w==\"", "The encrypted byte array, represented in a base64-encoded string." }, { "decryptHexAES", "Decrypts a hex-encoded byte array into hex-encoded plan bytes", "decryptHexAES(key, iv, \"F4397E6D9519DFF453F6640D94A235E3\") // this should return \"48656C6C6F20776F726C6421\"", "The decrypted plain text." }, { "encryptHexAES", "Encrypts hex-encoded plan bytes into hex-encoded bytes", "encryptHexAES(key, iv, \"Hello world!\") // this should return \"F4397E6D9519DFF453F6640D94A235E3\"", "The encrypted byte array, represented in a hex-encoded string." } };
}
